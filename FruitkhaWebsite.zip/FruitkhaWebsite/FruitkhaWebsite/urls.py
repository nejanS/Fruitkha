from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from appMy.views import *
from appUser.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', indexPage, name='indexPage'),
    path('about/', aboutPage, name='aboutPage'),
    path('contact/', contactPage, name='contactPage'),
    path('detail/<slug>/', detailPage, name='detailPage'),
    # path('detail/<slug:slug>/', detailPage, name='detail-page'),

    path('shop/', shopPage, name='shopPage'),
    path('basket/', basketPage, name='basketPage'),
    
    # === USER ===
    path('login/', loginUser, name='loginUser'),
    path('logout/015758/', logoutUser, name='logoutUser'), # url kısmını şifreleyerek kullanıcının url üzerinden çıkış yapması engellenir
    path('register/', registerUser, name='registerUser'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)