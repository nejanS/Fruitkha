from django.db import models
from django.contrib.auth.models import User


class UserInfo(models.Model):
    CHOICES = [
        ("yetkili","yetkili"),
        ("satici","satici"),
        ("musteri","musteri"),
    ]
    
    user = models.OneToOneField(User, verbose_name=("Kullanıcı"), on_delete=models.CASCADE)
    image = models.ImageField(("Profile"), upload_to="user", max_length=300, default="default/user.jpg")
    address = models.TextField(("Kullanıcı Adresi"), default="", blank=True) # alanı doldurmadan geçmeye izin vermesi için blank true gönderildi
    group = models.CharField(("Kullanıcı Seçeneği"), choices=CHOICES, max_length=50, default="musteri")  # kullanıcının müşteri, satıcı veya yetkili olduğunu ayırt eder

    def __str__(self):
        return self.user.username
    