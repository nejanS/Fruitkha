from django.shortcuts import render,redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib import messages

def loginUser(request):

    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        
        user = authenticate(username=username, password=password)
        rememberme = request.POST.get("rememberme")
        
        if user is not None:
            login(request,user)
            messages.success(request, "You are logged in...")
            
            if rememberme:
                request.session.set_expiry(604800) # sayfaya giriş yapınca 1 hafta boyunca sayfa açık kalacak hatırlamasını sağlayacak
                
            
            return redirect("indexPage")
        else:
            messages.error(request,"Username or Password Fail...")

    context = {}
    return render(request, 'user/login.html',context)

def logoutUser(request):
    logout(request)
    return redirect("loginUser")

def registerUser(request):
    
    if request.method == "POST":
        l_name = request.POST.get("l_name")
        f_name = request.POST.get("f_name")
        username = request.POST.get("username")
        email = request.POST.get("email")
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")
        
        len_pass = up_pass = num_pass = bool_user = bool_email = False
        
        if password1 == password2:
            
            if len(password1)>=6:
                len_pass = True
            else:
                messages.error(request,'Your password must be at least 6 characters.')
            
            for i in password1:
                if i.isupper():up_pass = True
                if i.isdigit():num_pass = True
            
            if not up_pass:
                messages.error(request, "You must use at least one capital letter in the password!")
            if not num_pass:
                messages.error(request, "You must use at least one number in the password!")
            if not User.objects.filter(username=username).exists():
                bool_user = True
            else:
                messages.error(request, "This username already exists.")
            if not User.objects.filter(email=email).exists():
                bool_email = True
            else:
                messages.error(request, "This e-mail address is already registered.")
            
            
            if len_pass and up_pass and num_pass and bool_user and bool_email:
                user = User.objects.create_user(username=username, email=email, first_name=f_name, last_name=l_name, password=password1)
                user.save()
                messages.success(request, "Your registration was successfully completed.")
                return redirect("loginUser")
            else:
                return redirect("registerUser")
        else:
            messages.error(request, "Passwords do not match.")
        
    context = {}
    return render(request, 'user/register.html',context)



