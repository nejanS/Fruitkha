from django.contrib import admin
from .models import *

@admin.register(Brand)
class BrandAdmin(admin.ModelAdmin):
    list_display = ('title',)
    readonly_fields = ('slug',)

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('title',)
    readonly_fields = ('slug',)

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'brand', 'category', 'price',)
    readonly_fields = ('slug',)
    search_fields = ('title', 'brand__title', 'category__title',)

@admin.register(ProductInfo)
class ProductInfoAdmin(admin.ModelAdmin):
    list_display = ('product', 'stok',)
    search_fields = ('product__title', 'stok',)

@admin.register(Image)
class ImageAdmin(admin.ModelAdmin):
    list_display = ('product', 'image',)
    search_fields = ('product__title',)
