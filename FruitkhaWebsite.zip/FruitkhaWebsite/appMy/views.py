from django.shortcuts import render
from .models import *
from django.http import JsonResponse


def indexPage(request):
    context = {}
    return render(request, "index.html", context)

def aboutPage(request):
    context = {}
    return render(request, "about.html", context)

def contactPage(request):
    context = {}
    return render(request, "contact.html", context)

def detailPage(request, slug):
    
    # product_info = Product.objects.filter(product__title=slug).first()
    product_detail = ProductInfo.objects.filter(product__title=slug).first()
    # print(product_info)
   
    context = {
        # "product_info":product_info,
        "product_detail":product_detail,
    }
    return render(request, "detail.html", context)

def shopPage(request):
    
    product_list = Product.objects.all()
    
    context = {
        "product_list":product_list,
    }
    return render(request, "shop.html", context)

def basketPage(request):
    context = {}
    return render(request, "basket.html", context)

