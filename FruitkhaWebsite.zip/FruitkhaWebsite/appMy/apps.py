from django.apps import AppConfig


class AppmyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appMy'
    verbose_name = 'product'
