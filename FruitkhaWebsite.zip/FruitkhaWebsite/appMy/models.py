from django.db import models
from django.utils.text import slugify
from django.contrib.auth.models import User

class Brand(models.Model):
    title = models.CharField(("Marka Başlık"), max_length=50)
    slug = models.SlugField(("Slug"), blank=True, unique=True)

    def save(self):
        self.slug = slugify(self.title)
        super().save()
        
    def __str__(self) -> str:
        return self.title

class Category(models.Model):
    title = models.CharField(("Marka Başlık"), max_length=50)
    slug = models.SlugField(("Slug"), blank=True, unique=True)

    def save(self):
        self.slug = slugify(self.title)
        super().save()
        
    def __str__(self) -> str:
        return self.title

class Product(models.Model):
    user = models.ForeignKey(User, verbose_name=("Kullanıcı"), on_delete=models.CASCADE)
    brand = models.ForeignKey(Brand, verbose_name=("Marka"), on_delete=models.CASCADE)
    category = models.ForeignKey(Category, verbose_name=("Kategori"), on_delete=models.CASCADE)
    title = models.CharField(("Başlık"), max_length=50)
    unit = models.CharField(("Unit"), max_length=20, default='Per kg')
    price = models.FloatField(("Fiyat"))
    description = models.TextField(("Açıklama"), default="")
    comments = models.IntegerField(("Yorum Sayısı"), default=0)
    slug = models.SlugField(("Slug"), blank=True, null=True)
    image = models.ImageField(("Ürün Resmi"), upload_to="product", max_length=350, null=True)
    

    def __str__(self) -> str:
        return self.title
    
class ProductInfo(models.Model):
    product = models.ForeignKey(Product, verbose_name=("Ürün"), on_delete=models.CASCADE)
    stok = models.IntegerField(("Stok"), default=0)

    def __str__(self) -> str:
        return self.product.title

class Image(models.Model):
   product = models.ForeignKey(Product, verbose_name=("Ürün"), on_delete=models.CASCADE, null=True, related_name='product')
   image = models.ImageField(("Resim"), upload_to="product", max_length=400)

   def __str__(self) -> str:
      return self.product.title

